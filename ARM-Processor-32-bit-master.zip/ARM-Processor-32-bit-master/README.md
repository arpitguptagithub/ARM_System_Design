# ARM-Processor-32-bit
A 32-bit Arm Processor Using Verilog HDL With Hazard Detection, Forwarding Unit, SRAM Memory & A 2-Way Set-Associative Cache.
